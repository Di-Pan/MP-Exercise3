import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flutter/material.dart';
import 'ball_catch_game.dart';
import 'bucket_component.dart';

abstract class BallComponent extends CircleComponent
    with CollisionCallbacks, HasGameReference<BallCatchGame> {
  late int points;
  late double fallSpeed;

  BallComponent({
    required super.position,
    required double radius,
    required Paint paint,
    required this.points,
    this.fallSpeed = 150.0,
  }) : super(radius: radius, paint: paint);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    add(CircleHitbox());
  }

  @override
  void update(double dt) {
    super.update(dt);
    position.y += fallSpeed * dt;

    // If ball goes off-screen and wasn't caught
    if (position.y > game.size.y + radius) {
      if (points > 0) {
        game.loseLife(); // Only lose life if it's not a bomb
      }
      removeFromParent();
    }
  }

  @override
  bool onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    super.onCollision(intersectionPoints, other);
    if (other is BucketComponent) {
      game.addScore(points);
      removeFromParent();
      return false;
    }
    return true;
  }
}

class WhiteBall extends BallComponent {
  WhiteBall({required Vector2 position})
      : super(
    position: position,
    radius: 15,
    paint: Paint()..color = Colors.white,
    points: 5,
    fallSpeed: 120.0,
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    add(CircleComponent(
      radius: radius + 2,
      paint: Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    ));
  }
}

class RedBall extends BallComponent {
  RedBall({required Vector2 position})
      : super(
    position: position,
    radius: 15,
    paint: Paint()..color = Colors.red,
    points: 10,
    fallSpeed: 140.0,
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    add(CircleComponent(
      radius: radius * 0.6,
      position: Vector2(-radius * 0.3, -radius * 0.3),
      paint: Paint()..color = Colors.red[300]!,
    ));
  }
}

class GoldBall extends BallComponent {
  GoldBall({required Vector2 position})
      : super(
    position: position,
    radius: 18,
    paint: Paint()..color = Colors.yellow[700]!,
    points: 15,
    fallSpeed: 160.0,
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    add(CircleComponent(
      radius: radius * 0.5,
      position: Vector2(-radius * 0.2, -radius * 0.2),
      paint: Paint()..color = Colors.yellow[200]!,
    ));
    add(RectangleComponent(
      size: Vector2(4, 4),
      position: Vector2(-2, -2),
      paint: Paint()..color = Colors.white,
    ));
  }
}

class BombBall extends BallComponent {
  BombBall({required Vector2 position})
      : super(
    position: position,
    radius: 16,
    paint: Paint()..color = Colors.black,
    points: -30,
    fallSpeed: 100.0,
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    add(RectangleComponent(
      size: Vector2(2, 8),
      position: Vector2(-1, -radius - 8),
      paint: Paint()..color = Colors.brown,
    ));
    add(CircleComponent(
      radius: 3,
      position: Vector2(0, -radius - 8),
      paint: Paint()..color = Colors.orange,
    ));
    add(TextComponent(
      text: '💣',
      position: Vector2(-8, -8),
      textRenderer: TextPaint(
        style: const TextStyle(fontSize: 16),
      ),
    ));
  }
}
