import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import 'ball_catch_game.dart';

void main() {
  runApp(const GameApp());
}

class GameApp extends StatelessWidget {
  const GameApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ball Catch Game',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Arial',
      ),
      home: const GamePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  late BallCatchGame game;
  bool gameStarted = false;

  @override
  void initState() {
    super.initState();
    game = BallCatchGame();
    game.onGameStateChange = () {
      setState(() {}); // Re-render when gameOver or gameWon happens
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // strong contrast
      body: Stack(
        children: [
          GameWidget(game: game),
          if (!gameStarted && !game.isGameWon && !game.isGameOver)
            _buildStartScreen(),
          if (game.isGameWon)
            _buildCongratulationScreen(),
          if (game.isGameOver)
            _buildGameOverScreen(),
        ],
      ),
    );
  }

  Widget _buildStartScreen() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: const Color.fromRGBO(33, 150, 243, 0.8),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Catch the Balls!',
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 20),
            const Text('Goal: Reach 100 Points', style: TextStyle(fontSize: 24, color: Colors.white)),
            const SizedBox(height: 10),
            const Text(
              'White Ball: +5  |  Red Ball: +10\nGold Ball: +15  |  Bomb: -30\nMiss a ball = lose 1 life (2 total)',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.white70),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  gameStarted = true;
                });
                game.startGame();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                child: Text('Start', style: TextStyle(fontSize: 24)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameOverScreen() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.black.withOpacity(0.8),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.sentiment_very_dissatisfied, color: Colors.white, size: 100),
            const SizedBox(height: 20),
            const Text(
              'Game Over',
              style: TextStyle(fontSize: 60, fontWeight: FontWeight.bold, color: Colors.red),
            ),
            const SizedBox(height: 20),
            Text(
              'Your Score: ${game.score}',
              style: const TextStyle(fontSize: 32, color: Colors.white),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  gameStarted = false;
                  game = BallCatchGame()..onGameStateChange = () => setState(() {});
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                child: Text('Restart Game', style: TextStyle(fontSize: 20)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCongratulationScreen() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.yellow, Colors.orange],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🎉', style: TextStyle(fontSize: 100)),
            const SizedBox(height: 20),
            const Text(
              'Victory!',
              style: TextStyle(fontSize: 60, fontWeight: FontWeight.bold, color: Colors.red),
            ),
            const SizedBox(height: 20),
            Text(
              'You scored ${game.score} points!',
              style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  gameStarted = false;
                  game = BallCatchGame()..onGameStateChange = () => setState(() {});
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                child: Text('Play Again', style: TextStyle(fontSize: 20)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
