import 'dart:math';
import 'dart:async' as dart_async;
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'bucket_component.dart';
import 'ball_components.dart';

class BallCatchGame extends FlameGame with HasCollisionDetection, PanDetector {
  late BucketComponent bucket;
  late TextComponent scoreText;
  late TextComponent livesText;

  int score = 0;
  int lives = 3;

  bool isGameActive = false;
  bool isGameWon = false;
  bool isGameOver = false;

  dart_async.Timer? ballSpawnTimer;
  final Random random = Random();

  double spawnInterval = 1.5;
  final double minSpawnInterval = 0.8;

  // External notifier callback (set from UI)
  void Function()? onGameStateChange;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    bucket = BucketComponent(
      position: Vector2(size.x / 2 - 40, size.y - 120),
      size: Vector2(80, 30),
    );
    add(bucket);

    scoreText = TextComponent(
      text: 'Score: 0',
      position: Vector2(20, 20),
      anchor: Anchor.topLeft,
      textRenderer: TextPaint(
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
    add(scoreText);

    livesText = TextComponent(
      text: 'Lives:❤️❤️❤️',//❤️❤️❤️
      position: Vector2(size.x - 20, 20),
      anchor: Anchor.topRight,
      textRenderer: TextPaint(
        style: const TextStyle(
          color: Colors.red,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
    add(livesText);
  }

  void startGame() {
    isGameActive = true;
    isGameWon = false;
    isGameOver = false;
    score = 0;
    lives = 3;
    updateScoreDisplay();
    updateLivesDisplay();
    _startBallSpawn();
    onGameStateChange?.call(); // Notify UI to refresh
  }

  void _startBallSpawn() {
    ballSpawnTimer?.cancel();
    ballSpawnTimer = dart_async.Timer.periodic(
      Duration(milliseconds: (spawnInterval * 1000).round()),
          (timer) {
        if (!isGameActive || isGameWon || isGameOver) {
          timer.cancel();
          return;
        }
        _spawnRandomBall();
        if (spawnInterval > minSpawnInterval) {
          spawnInterval -= 0.02;
        }
      },
    );
  }

  void _spawnRandomBall() {
    final x = random.nextDouble() * (size.x - 30);
    final ballType = random.nextInt(100);

    BallComponent ball;
    if (ballType < 45) {
      ball = WhiteBall(position: Vector2(x, -30));
    } else if (ballType < 75) {
      ball = RedBall(position: Vector2(x, -30));
    } else if (ballType < 90) {
      ball = GoldBall(position: Vector2(x, -30));
    } else {
      ball = BombBall(position: Vector2(x, -30));
    }

    add(ball);
  }

  void addScore(int points) {
    score += points;
    updateScoreDisplay();

    if (score >= 100 && !isGameWon) {
      winGame();
    }
  }

  void loseLife() {
    lives -= 1;
    updateLivesDisplay();
    if (lives <= 0) {
      gameOver();
    }
  }

  void updateScoreDisplay() {
    scoreText.text = 'Score: $score';
  }

  void updateLivesDisplay() {
    livesText.text = 'Lives: ${'❤️' * lives}';
  }

  void winGame() {
    isGameActive = false;
    isGameWon = true;
    ballSpawnTimer?.cancel();
    children.whereType<BallComponent>().forEach((ball) => ball.removeFromParent());
    onGameStateChange?.call();
  }

  void gameOver() {
    isGameActive = false;
    isGameOver = true;
    ballSpawnTimer?.cancel();
    children.whereType<BallComponent>().forEach((ball) => ball.removeFromParent());
    onGameStateChange?.call();
  }

  @override
  void onPanUpdate(DragUpdateInfo info) {
    if (isGameActive && !isGameWon && !isGameOver) {
      bucket.moveHorizontally(info.delta.global.x);
    }
  }

  @override
  void onRemove() {
    ballSpawnTimer?.cancel();
    super.onRemove();
  }
}
