import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flutter/material.dart';

class BucketComponent extends RectangleComponent with CollisionCallbacks, HasGameReference {
  late RectangleHitbox catchArea;

  BucketComponent({
    required super.position,
    required super.size,
  }) : super(paint: Paint()..color = Colors.brown);

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    catchArea = RectangleHitbox(
      size: Vector2(size.x, 8),
      position: Vector2(0, -4),
    );
    add(catchArea);

    add(RectangleComponent(
      size: Vector2(size.x, 4),
      position: Vector2(0, -2),
      paint: Paint()..color = Colors.orange,
    ));

    add(RectangleComponent(
      size: Vector2(size.x + 4, 2),
      position: Vector2(-2, -4),
      paint: Paint()..color = Colors.black87,
    ));
  }

  void moveHorizontally(double deltaX) {
    final gameSize = game.size;
    position.x = (position.x + deltaX).clamp(0, gameSize.x - size.x);
  }

  @override
  bool onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    super.onCollision(intersectionPoints, other);
    return true;
  }
}
