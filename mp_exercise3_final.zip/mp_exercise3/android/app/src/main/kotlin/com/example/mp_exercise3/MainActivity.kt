package com.example.mp_exercise3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
